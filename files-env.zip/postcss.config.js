module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
    // 'postcss-import': {},
    // 'postcss-nesting': {},
    // cssImport: {},
    // cssNesting: {},
  },
};
